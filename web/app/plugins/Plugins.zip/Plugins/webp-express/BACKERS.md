
# Backers

WebP Express is an MIT-licensed open source project. It is free and always will be.

How is it financed then? Well, it isn't exactly. However, some people choose to support the development by buying me a cup of coffee, and some go even further, by becoming backers. Backers are nice folks making recurring monthly donations, and by doing this, they give me an excuse to put more work into the plugin than I really should.

To become a backer, yourself, [go to my GitHub sponsors page](https://github.com/sponsors/rosell-dk)

PS: I just started using GitHub Sponsors instead of patreon. I'm keeping [my patreon page]((https://www.patreon.com/rosell)), but might change it to support some other project. I'm for example very curious about the nature of reality and if we might be living in a computer simulation, and I might want to write a book about it one day.

## Generous backers via Patron

Generous backers will get their names listed here.

There are no generous backers yet. [Be the first!](https://www.patreon.com/rosell)

<sub>
I reserve the right to disallow inappropriate messages and links. No xxx sites or anything freaky or fishy, please. You may however advertise non-freaky-or-fishy things, if you wish. Just remember the audience. No point in trying to sell shoes here</sub>


## Active backers via Patron

| Name                   | Since date     |
| ---------------------- | -------------- |
| Max Kreminsky          | 2019-08-02     |
| [Mathieu Gollain-Dupont](https://www.linkedin.com/in/mathieu-gollain-dupont-9938a4a/) | 2020-08-26     |
| Nodeflame              | 2019-10-31     |
| Ruben Solvang          | 2020-01-08     |


Hi-scores:

| Name                     | Life time contribution   |
| ------------------------ | ------------------------ |
| Tammy Valgardson         | $90                      |        
| Max Kreminsky            | $65                      |        
| Ruben Solvang            | $14                      |        
| Dmitry Verzjikovsky      | $5                       |        

## Former backers - I'm still grateful :)
- Dmitry Verzjikovsky
- Tammy Valgardson
