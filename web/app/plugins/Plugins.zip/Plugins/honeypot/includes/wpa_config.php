<?php
if ( ! defined( 'ABSPATH' ) ) exit; 
$GLOBALS['wpa_version']					= '2.2.06';
$GLOBALS['wpa_field_name'] 				= get_option('wpa_field_name');
$GLOBALS['wpa_error_message'] 			= get_option('wpa_error_message');
$GLOBALS['wpa_disable_test_widget'] 	= get_option('wpa_disable_test_widget');